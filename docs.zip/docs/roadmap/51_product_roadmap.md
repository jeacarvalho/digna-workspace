# Product Roadmap

Phase 1
Contabilidade invisível

Phase 2
Formalização automática

Phase 3
Moedas sociais

Phase 4
Ecossistema de crédito