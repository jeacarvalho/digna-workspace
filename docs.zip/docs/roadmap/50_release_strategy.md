# Release Strategy

v0 — demonstração operacional  
v1 — integração institucional  
v2 — finanças solidárias  
v3 — intercooperação nacional