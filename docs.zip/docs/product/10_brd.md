# 📝 BRD - Business Requirements Document: Digna

**Referência Técnica:** Lei nº 15.068/2024 (Lei Paul Singer) / ITG 2002  
**ID de Verificação:** BRD-DIGNA-2026-001

---

## 1. Requisitos Funcionais (RF)

### [RF-01] PDV Operacional Soberano
* **Descrição:** Interface simplificada para registro de Vendas e Compras.
* **Regra:** Cada venda deve gerar automaticamente uma "Entry" e dois "Postings" (D/C) no Ledger.
* **Prioridade:** Essencial (v0).

### [RF-02] Registro de Trabalho (ITG 2002)
* **Descrição:** Captura de horas/minutos trabalhados por membros.
* **Regra:** O tempo deve ser registrado em `int64` e ser a base primária para o rateio de sobras sociais.

### [RF-03] Motor de Reservas Obrigatórias
* **Descrição:** Segregação automática de fundos antes da distribuição de resultados.
* **Regra:** Bloqueio mandatório de **10% (Reserva Legal)** e **5% (FATES)** sobre o excedente.

### [RF-04] Dossiê de Formalização (CADSOL)
* **Descrição:** Exportação de Atas de Assembleia e Relatórios de Impacto Social.
* **Regra:** O documento deve ser gerado em Markdown/PDF com Hash de integridade.

---

## 2. Requisitos Não Funcionais (RNF)

### [RNF-01] Isolamento por Tenant (Soberania)
* **Descrição:** Cada "Sonho" ou Cooperativa deve ter seu próprio arquivo `.sqlite`.
* **Métrica:** Tempo de criação de nova instância < 500ms.

### [RNF-02] Rigor Monetário (Anti-Float)
* **Descrição:** Proibição de tipos de ponto flutuante em todo o Core Lume.
* **Regra:** Uso obrigatório de `int64` para representar centavos.

### [RNF-03] Resiliência (Offline-First)
* **Descrição:** A interface (PWA) deve permitir operações básicas sem internet, sincronizando via Delta-Tracking quando houver conexão.

---

## 3. Matriz de Rastreabilidade (Regras Contábeis)

| Operação | Gatilho | Impacto no Ledger | Requisito Relacionado |
| :--- | :--- | :--- | :--- |
| Venda no Balcão | PDV Submit | D: Ativo / C: Receita | RF-01 |
| Fim de Turno | Log Horas | Registro de Cota-Trabalho | RF-02 |
| Fechamento Mes | Batch Job | Cálculo de Reservas (15%) | RF-03 |

---

## 🛡️ CLÁUSULA ANTI-ALUCINAÇÃO (Obrigatória para IAs)
O Agente de IA deve validar qualquer proposta de código contra os IDs [RF-XX] e [RNF-XX] deste documento. Caso uma funcionalidade proposta altere o comportamento de isolamento de dados (RNF-01) ou introduza tipos `float` (RNF-02), o Agente deve **abortar a operação** e solicitar revisão do operador.