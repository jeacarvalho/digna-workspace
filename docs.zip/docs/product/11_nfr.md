# Non Functional Requirements

## Performance

- criação de tenant < 500ms

## Integridade Financeira

- todos os cálculos em int64

## Offline Capability

- operação sem internet

## Escalabilidade

- suporte a milhões de entidades

## Segurança

- isolamento de dados por entidade