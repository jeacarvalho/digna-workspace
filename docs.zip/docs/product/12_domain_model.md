# Domain Model

## Entities

### Enterprise
Empreendimento de economia solidária.

### Member
Pessoa participante do empreendimento.

### Transaction
Evento econômico.

### WorkLog
Registro de trabalho.

### Decision
Decisão coletiva registrada.

### Fund
Fundos obrigatórios (reserva, FATES).

## Aggregates

Enterprise
  ├ Members
  ├ Transactions
  ├ WorkLogs
  └ Decisions