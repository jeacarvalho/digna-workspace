# Data Model

## Tables

accounts  
entries  
postings  
work_logs  
decisions_log  
sync_metadata  

## Relationships

entries
   └ postings

enterprise
   └ work_logs