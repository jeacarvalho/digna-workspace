# Sync Protocol

## Model

Delta-based synchronization.

## Package

entity_id  
timestamp  
chain_digest  
aggregated_data  

## Privacy

não transmite dados pessoais.