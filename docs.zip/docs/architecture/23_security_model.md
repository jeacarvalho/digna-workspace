# Security Model

## Data Isolation

cada entidade possui banco próprio.

## Integrity

hash SHA256 para auditoria.

## Transport

pacotes assinados digitalmente.