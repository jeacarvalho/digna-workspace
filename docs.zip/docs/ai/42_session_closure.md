# Session Closure

Ao final de cada sessão:

- atualizar SESSION_LOG
- registrar decisões
- documentar mudanças arquiteturais