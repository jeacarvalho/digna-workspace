# Risk Register

| Risk | Probability | Impact | Mitigation |
|-----|------------|--------|-----------|
| Perda de dados locais | Medium | High | backup automatizado |
| Uso incorreto do sistema | Medium | Medium | UX simplificada |
| Bugs contábeis | Low | Critical | testes contábeis |
| Complexidade institucional | Medium | High | documentação clara |
| Dependência tecnológica | Low | High | open source |

## Technical Risks

- inconsistência no ledger
- falhas na sincronização
- corrupção de banco SQLite

## Governance Risks

- captura institucional
- fragmentação da comunidade