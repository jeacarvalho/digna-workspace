# Vision — Digna

O Digna é uma infraestrutura contábil soberana para a Economia Solidária brasileira.

Seu objetivo é transformar operações econômicas cotidianas em registros contábeis automáticos baseados em partidas dobradas.

## Princípio central

O empreendedor não faz contabilidade.

Ele apenas:

- vende
- compra
- trabalha
- decide coletivamente

O sistema traduz essas ações em contabilidade formal.

## Princípios do Sistema

### Contabilidade Invisível
A contabilidade é gerada automaticamente a partir das operações.

### Soberania de Dados
Cada entidade possui seu próprio banco SQLite.

### Primazia do Trabalho
O trabalho coletivo é registrado como capital social.

### Escala Nacional
Arquitetura preparada para milhões de empreendimentos.