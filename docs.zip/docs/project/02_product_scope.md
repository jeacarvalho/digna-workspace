# Product Scope — Digna

## Product Type

Infraestrutura contábil e institucional para economia solidária.

## Core Capabilities

### 1. PDV Operacional
Registro simplificado de vendas e compras.

### 2. Ledger Contábil
Motor de partidas dobradas automático.

### 3. Registro de Trabalho
Captura de horas de trabalho cooperativo.

### 4. Documentação Institucional
Geração automática de:

- atas
- relatórios
- dossiês de formalização

### 5. Sincronização Offline
Operação mesmo sem internet.

## Excluded Features

- ERP completo
- folha de pagamento empresarial
- contabilidade fiscal complexa
- gestão financeira bancária