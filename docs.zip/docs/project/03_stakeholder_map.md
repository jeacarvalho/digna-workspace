# Stakeholder Map

## Primary Users

| Stakeholder | Role |
|-------------|------|
| Cooperativas | Usuários principais |
| Associações | Gestão coletiva |
| Grupos informais | Entrada no sistema |

## Institutional Stakeholders

| Stakeholder | Interest |
|-------------|---------|
| Ministério do Trabalho | Política pública |
| Senaes | Economia solidária |
| Serpro | Infraestrutura tecnológica |

## Supporting Stakeholders

| Stakeholder | Role |
|-------------|------|
| Universidades | Pesquisa |
| ONGs | apoio territorial |
| incubadoras | formação cooperativa |

## Governance Stakeholders

| Stakeholder | Role |
|-------------|------|
| Fundação Providentia | governança |
| PMC | decisões técnicas |
| comunidade dev | evolução do software |