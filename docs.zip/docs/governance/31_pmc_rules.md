# Project Management Committee

Responsável por:

- decisões técnicas
- roadmap
- revisão de código

Entrada baseada em mérito técnico.