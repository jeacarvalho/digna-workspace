# Licensing

Código: Apache 2.0

Marca "Digna" pertence à Fundação Providentia.