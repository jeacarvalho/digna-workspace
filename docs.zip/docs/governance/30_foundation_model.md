# Foundation Governance

A Fundação Providentia garante:

- neutralidade
- missão social
- continuidade do projeto

Modelo inspirado em Apache Foundation.