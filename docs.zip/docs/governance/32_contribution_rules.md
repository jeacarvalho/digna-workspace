# Contribution Rules

Todos podem contribuir.

Processo:

1 Pull Request
2 Revisão
3 Aprovação PMC